import type { ReactElement } from "react";

type Card = {
  title: string;
  description?: string;
  icon?: ReactElement;
  tag?: string;
};

const services: Card[] = [
  {
    title: "تصميم مخصص",
    description: "نحول فكرتك إلى شكل متكامل يعكس هوية علامتك.",
    icon: iconCube(),
  },
  {
    title: "تصنيع احترافي",
    description: "مواد عالية الجودة وتشطيبات فاخرة مقاومة للعوامل الجوية.",
    icon: iconShield(),
  },
  {
    title: "تجهيز كامل",
    description: "معدات، كهرباء، إضاءة، سباكة وكل ما يلزم للتشغيل الفوري.",
    icon: iconSpark(),
  },
  {
    title: "توصيل وتركيب",
    description: "نصل إليك في أي مدينة ونقوم بالتركيب والتسليم الجاهز للعمل.",
    icon: iconRoute(),
  },
];

const advantages = [
  "💰 تكلفة أقل من المحلات التقليدية",
  "🚀 مشروع سريع الانطلاق",
  "📍 حرية اختيار الموقع",
  "🛠️ قابل للتخصيص الكامل",
  "⚡ جاهز للتشغيل",
  "🎯 مناسب للمبتدئين",
];

const products = [
  { title: "Food Bike (دراجة قهوة)", tag: "متحرك" },
  { title: "كشك ثابت", tag: "متين" },
  { title: "مقهى متنقل بعجلات", tag: "مرن" },
  { title: "كوفي كورنر مضيء", tag: "نيون" },
];

const reasons = [
  "جودة عالية",
  "تصميم عصري جذاب",
  "دعم ومواكبة",
  "أسعار تنافسية",
];

const testimonials: Card[] = [
  {
    title: "أطلقت مشروعي في أقل من شهر، التصميم فاخر وكل شيء جاهز للتشغيل",
    description: "سلمى — مؤسسة كوفي بايك",
  },
  {
    title: "الكشك شد الانتباه في المول، الإضاءة الذهبية والنيون أعطت طابع راقي",
    description: "أمين — رائد أعمال",
  },
];

const listCTA = [
  "استشارة مجانية لمدة 20 دقيقة",
  "مخطط تجهيز كهرباء ومياه",
  "تصميم أولي خلال 72 ساعة",
];

export default function App() {
  return (
    <div className="min-h-screen" dir="rtl">
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_30%_20%,rgba(52,104,255,0.08),transparent_25%),radial-gradient(circle_at_70%_0%,rgba(212,175,55,0.12),transparent_25%),linear-gradient(145deg,#05070d,#0b1221)]" />
      <div className="fixed inset-0 -z-[8] bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.08]" />

      <div className="mx-auto max-w-6xl px-4 pb-20 pt-6 md:px-8">
        <header className="sticky top-4 z-20 mb-8 flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur-xl shadow-lg shadow-black/30">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-[#d4af37] to-[#f5e6a2] text-[#0b0d12] shadow-lg shadow-[#d4af37]/40">
              <span className="text-lg font-black">R</span>
            </div>
            <div className="leading-tight">
              <p className="text-xs tracking-[0.2em] text-[#d4af37]">RESTOVANE</p>
              <p className="text-lg font-semibold text-white">ريسطوفان</p>
            </div>
          </div>
          <nav className="hidden items-center gap-4 text-sm text-slate-200/90 md:flex">
            <a className="transition hover:text-[#d4af37]" href="#about">
              من نحن
            </a>
            <a className="transition hover:text-[#d4af37]" href="#services">
              الخدمات
            </a>
            <a className="transition hover:text-[#d4af37]" href="#products">
              المنتجات
            </a>
            <a className="transition hover:text-[#d4af37]" href="#contact">
              تواصل
            </a>
          </nav>
          <a
            href="#contact"
            className="rounded-full bg-gradient-to-r from-[#d4af37] to-[#f7d25a] px-4 py-2 text-sm font-semibold text-[#0b0d12] shadow-md shadow-[#d4af37]/40 transition hover:scale-105"
          >
            اطلب تصميمك الآن
          </a>
        </header>

        <main className="space-y-12 md:space-y-14">
          <section
            id="hero"
            className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/5 via-white/5 to-white/[0.03] p-8 shadow-2xl backdrop-blur-xl md:p-12"
          >
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_60%_10%,rgba(52,104,255,0.12),transparent_30%),radial-gradient(circle_at_10%_40%,rgba(212,175,55,0.2),transparent_25%)]" />
            <div className="pointer-events-none absolute inset-0 opacity-50 blur-3xl" />
            <div className="relative grid gap-10 md:grid-cols-[1.1fr_0.9fr] md:items-center">
              <div className="space-y-5">
                <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-[#d4af37]">
                  <span className="h-2 w-2 rounded-full bg-[#34d8ff]" /> تصنيع المقاهي المتنقلة والأكشاك العصرية
                </div>
                <h1 className="text-4xl font-black leading-[1.05] text-white md:text-5xl">ريسطوفان</h1>
                <p className="text-xl text-slate-200/90">
                  نصنع المقاهي المتنقلة والأكشاك حسب الطلب — تصميم فاخر، تشطيب دقيق، وجاهزية للتشغيل من اليوم الأول.
                </p>
                <div className="flex flex-wrap gap-3">
                  <a
                    href="#contact"
                    className="rounded-full bg-gradient-to-r from-[#d4af37] via-[#f2d46d] to-[#34d8ff] px-6 py-3 text-base font-semibold text-[#0b0d12] shadow-lg shadow-[#d4af37]/30 transition hover:scale-[1.02]"
                  >
                    اطلب تصميمك الآن
                  </a>
                  <a
                    href="#products"
                    className="rounded-full border border-white/20 px-6 py-3 text-base font-semibold text-white transition hover:border-[#d4af37]/70 hover:text-[#d4af37]"
                  >
                    شاهد أعمالنا
                  </a>
                </div>
                <div className="grid gap-4 text-sm text-slate-200/80 md:grid-cols-3">
                  {[
                    { label: "مدة الإنجاز", value: "30 يوم" },
                    { label: "ضمان", value: "12 شهر" },
                    { label: "جاهزية", value: "تسليم وتشغيل" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-inner shadow-white/5">
                      <p className="text-2xl font-bold text-white">{item.value}</p>
                      <p className="text-[#d4af37]">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="absolute -left-10 -top-8 h-24 w-24 rounded-full bg-[#34d8ff]/20 blur-3xl" />
                <div className="absolute -right-10 bottom-0 h-32 w-32 rounded-full bg-[#d4af37]/25 blur-3xl" />
                <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/0 p-6 shadow-xl shadow-black/40 ring-1 ring-white/10">
                  <div className="flex items-center justify-between text-sm text-slate-200/80">
                    <p>لوحة عرض</p>
                    <span className="rounded-full bg-[#34d8ff]/20 px-3 py-1 text-[#34d8ff]">متحرك</span>
                  </div>
                  <div className="mt-4 grid gap-3 text-xs text-slate-200/80">
                    {["هيكل ألمنيوم أسود مطفي", "إضاءة LED نيون زرقاء", "سقف زجاجي مضاد للأشعة"].map((item) => (
                      <div key={item} className="flex items-center justify-between rounded-xl border border-white/5 bg-white/5 px-3 py-2">
                        <span>{item}</span>
                        <span className="h-2 w-2 rounded-full bg-[#d4af37]" />
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 rounded-xl border border-white/10 bg-gradient-to-r from-[#0b0d12] to-[#0f1628] p-4 text-sm shadow-inner shadow-black/40">
                    <p className="font-semibold text-[#d4af37]">الرؤية</p>
                    <p className="text-slate-200/80">انطباع فاخر، تشغيل سريع، وحضور يلفت الانتباه في أي شارع.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section
            id="about"
            className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:p-10"
          >
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="space-y-3">
                <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">القصة</p>
                <h2 className="text-3xl font-bold text-white">من الفكرة إلى مقهى متنقل جاهز.</h2>
                <p className="text-slate-200/85">
                  ريسطوفان شركة متخصصة في تصميم وتصنيع المقاهي المتنقلة والأكشاك العصرية بجودة عالية وتصاميم احترافية. نعمل مع رواد الأعمال والشباب لتحويل رؤاهم إلى مشاريع ملموسة جاهزة للتشغيل.
                </p>
              </div>
              <div className="flex gap-3 text-sm text-slate-200/80">
                <span className="rounded-full bg-white/10 px-4 py-2">تصاميم فاخرة</span>
                <span className="rounded-full bg-white/10 px-4 py-2">جاهزية سريعة</span>
              </div>
            </div>
          </section>

          <section
            id="services"
            className="grid gap-6 rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:grid-cols-4 md:p-10"
          >
            {services.map((item) => (
              <div
                key={item.title}
                className="group relative flex flex-col gap-3 overflow-hidden rounded-2xl border border-white/10 bg-[#0b0d12]/70 p-5 shadow-lg shadow-black/40 transition hover:-translate-y-1 hover:border-[#d4af37]/50"
              >
                <div className="absolute -right-10 -top-10 h-24 w-24 rounded-full bg-[#34d8ff]/10 blur-2xl" />
                <div className="absolute -left-10 bottom-0 h-24 w-24 rounded-full bg-[#d4af37]/10 blur-2xl" />
                <div className="relative inline-flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 text-[#d4af37] shadow-inner shadow-white/10">
                  {item.icon ?? <span className="text-lg">★</span>}
                </div>
                <div className="relative space-y-2">
                  <h3 className="text-lg font-semibold text-white">{item.title}</h3>
                  <p className="text-sm text-slate-200/80">{item.description}</p>
                </div>
                <div className="mt-auto text-xs text-[#34d8ff]">جاهز للتنفيذ</div>
              </div>
            ))}
          </section>

          <section className="grid gap-6 rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:grid-cols-[1.1fr_0.9fr] md:p-10">
            <div className="space-y-4">
              <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">مزايا ريسطوفان</p>
              <h3 className="text-3xl font-bold text-white">لماذا يختارنا رواد المقاهي المتنقلة؟</h3>
              <p className="text-slate-200/85">
                نختصر المسافة بين الفكرة والتشغيل عبر حلول مصممة خصيصًا لبيئة الأعمال المتحركة.
              </p>
              <div className="grid gap-3 md:grid-cols-2">
                {advantages.map((item) => (
                  <div
                    key={item}
                    className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100"
                  >
                    <span>{item}</span>
                    <span className="h-2 w-2 rounded-full bg-[#d4af37]" />
                  </div>
                ))}
              </div>
            </div>
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-[#0b0d12] via-[#0f1628] to-[#0b0d12] p-6 shadow-inner shadow-black/40">
              <div className="absolute right-6 top-6 h-16 w-16 rounded-full bg-[#34d8ff]/20 blur-2xl" />
              <div className="absolute left-4 bottom-4 h-20 w-20 rounded-full bg-[#d4af37]/15 blur-2xl" />
              <div className="relative space-y-4">
                <p className="text-sm text-[#d4af37]">تفاصيل فاخرة</p>
                <p className="text-xl font-semibold text-white">
                  تشطيبات ذهبية، أسطح سوداء مطفية، وخطوط إضاءة نيون زرقاء تمنح مشروعك حضورًا معاصرًا.
                </p>
                <div className="grid gap-3 text-sm text-slate-200/80 md:grid-cols-2">
                  {["ألمنيوم مفرغ", "زجاج معالج", "LED IP65", "مخارج طاقة آمنة"].map((spec) => (
                    <div key={spec} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2">
                      {spec}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section
            id="products"
            className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:p-10"
          >
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">المنتجات</p>
                <h3 className="text-3xl font-bold text-white">معرض النماذج</h3>
              </div>
              <p className="text-sm text-slate-200/80">تصاميم سوداء عصرية بلمسات ذهبية ولمسات نيون زرقاء.</p>
            </div>
            <div className="mt-6 grid gap-6 md:grid-cols-4">
              {products.map((product) => (
                <div
                  key={product.title}
                  className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-[#0b0d12] to-[#111829] p-5 shadow-lg shadow-black/40 transition hover:-translate-y-1 hover:border-[#34d8ff]/50"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(52,216,255,0.12),transparent_45%),radial-gradient(circle_at_80%_80%,rgba(212,175,55,0.15),transparent_40%)] opacity-80" />
                  <div className="relative flex items-center justify-between text-sm text-slate-200/80">
                    <span className="rounded-full bg-white/5 px-3 py-1">{product.tag}</span>
                    <span className="h-2 w-2 rounded-full bg-[#d4af37]" />
                  </div>
                  <div className="relative mt-4 h-28 rounded-xl border border-white/10 bg-gradient-to-br from-[#0f1628] via-[#0b0d12] to-[#0f1628] shadow-inner shadow-black/40">
                    <div className="absolute inset-2 rounded-lg border border-white/5 bg-[linear-gradient(120deg,rgba(212,175,55,0.2),transparent),linear-gradient(300deg,rgba(52,216,255,0.25),transparent)] blur-[0.3px]" />
                    <div className="absolute bottom-2 left-2 right-2 h-2 rounded-full bg-[#34d8ff]/30 blur" />
                  </div>
                  <div className="relative mt-4 space-y-1">
                    <h4 className="text-lg font-semibold text-white">{product.title}</h4>
                    <p className="text-xs text-slate-200/70">تصميم أسود مطفي مع حواف ذهبية ولمسة نيون زرقاء.</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:p-10">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">لماذا ريسطوفان</p>
                <h3 className="text-3xl font-bold text-white">نعتني بكل التفاصيل.</h3>
              </div>
              <div className="flex gap-2 text-sm text-slate-200/80">
                <span className="rounded-full bg-white/10 px-3 py-1">خدمة ما بعد البيع</span>
                <span className="rounded-full bg-white/10 px-3 py-1">تصميم + تصنيع</span>
              </div>
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-4">
              {reasons.map((reason) => (
                <div
                  key={reason}
                  className="rounded-2xl border border-white/10 bg-[#0b0d12]/70 p-4 text-center text-slate-100 shadow-inner shadow-black/40"
                >
                  {reason}
                </div>
              ))}
            </div>
          </section>

          <section className="grid gap-6 rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl backdrop-blur-xl md:grid-cols-2 md:p-10">
            <div className="space-y-3">
              <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">آراء العملاء</p>
              <h3 className="text-3xl font-bold text-white">ثقة تُبنى على التجربة.</h3>
              <p className="text-slate-200/80">قصص نجاح لرواد أعمال أطلقوا مشاريعهم معنا.</p>
            </div>
            <div className="grid gap-4">
              {testimonials.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-2xl border border-white/10 bg-[#0b0d12]/70 p-4 shadow-inner shadow-black/40"
                >
                  <p className="text-white">{item.title}</p>
                  <p className="text-sm text-[#d4af37]">{item.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section
            id="contact"
            className="overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-r from-[#0b0d12] via-[#0f1628] to-[#0b0d12] p-8 shadow-2xl backdrop-blur-xl md:p-10"
          >
            <div className="grid gap-8 md:grid-cols-[1.1fr_0.9fr] md:items-center">
              <div className="space-y-4">
                <p className="text-sm uppercase tracking-[0.2em] text-[#d4af37]">تواصل</p>
                <h3 className="text-3xl font-bold text-white">ابدأ مشروع مقهى متنقل اليوم.</h3>
                <p className="text-slate-200/80">
                  اتصل بنا لمناقشة الفكرة والميزانية والموقع المثالي. فريقنا يجهز لك عرضًا واضحًا وخطوات تنفيذ محددة.
                </p>
                <div className="space-y-2 text-sm text-slate-200/85">
                  <p>
                    الهاتف: <a className="text-[#d4af37]" href="tel:+212649207108">+212 649-207108</a>
                  </p>
                  <p>
                    واتساب: <a className="text-[#34d8ff]" href="https://wa.me/212649207108">تواصل مباشر</a>
                  </p>
                </div>
                <div className="grid gap-2 text-sm text-slate-900 md:grid-cols-2">
                  {listCTA.map((item) => (
                    <div key={item} className="flex items-center gap-2 rounded-full bg-white/80 px-3 py-2 font-semibold">
                      <span className="h-2 w-2 rounded-full bg-[#34d8ff]" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/90 p-6 shadow-2xl shadow-black/30">
                <form className="space-y-4 text-slate-900">
                  <div className="grid gap-4 md:grid-cols-2">
                    <input
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm focus:border-[#d4af37] focus:outline-none"
                      placeholder="الاسم / العلامة"
                    />
                    <input
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm focus:border-[#d4af37] focus:outline-none"
                      placeholder="بريد إلكتروني"
                    />
                  </div>
                  <input
                    className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm focus:border-[#d4af37] focus:outline-none"
                    placeholder="نوع المشروع (دراجة قهوة، كشك، مقهى متنقل)"
                  />
                  <textarea
                    className="h-24 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm focus:border-[#d4af37] focus:outline-none"
                    placeholder="أخبرنا عن فكرتك والموقع والموعد المستهدف"
                  />
                  <button className="w-full rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f2d46d] to-[#34d8ff] px-4 py-3 text-sm font-semibold text-[#0b0d12] shadow-lg shadow-[#d4af37]/30 transition hover:scale-[1.01]">
                    إرسال الطلب
                  </button>
                </form>
              </div>
            </div>
          </section>
        </main>

        <footer className="mt-10 flex flex-col gap-3 border-t border-white/10 pt-6 text-sm text-slate-200/70 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2 text-white">
            <span className="h-2 w-2 rounded-full bg-[#34d8ff]" />
            ريسطوفان — تصميم وتصنيع المقاهي المتنقلة.
          </div>
          <div className="flex items-center gap-4">
            <a className="transition hover:text-[#d4af37]" href="#services">
              الخدمات
            </a>
            <a className="transition hover:text-[#d4af37]" href="#products">
              الأعمال
            </a>
            <span>© {new Date().getFullYear()} جميع الحقوق محفوظة</span>
          </div>
        </footer>

        <a
          href="https://wa.me/212649207108"
          className="fixed bottom-6 left-6 flex items-center gap-2 rounded-full bg-gradient-to-r from-[#34d8ff] to-[#0ea5e9] px-4 py-3 text-sm font-semibold text-[#0b0d12] shadow-lg shadow-[#34d8ff]/40 transition hover:scale-105"
        >
          واتساب مباشر
        </a>
      </div>
    </div>
  );
}

function iconCube() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6}>
      <path d="M12 3 4 7v10l8 4 8-4V7Z" />
      <path d="M4 7 12 11 20 7" />
      <path d="M12 11v10" />
    </svg>
  );
}

function iconShield() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6}>
      <path d="M12 3 5 5v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V5Z" />
      <path d="M9 12.5 11 15l4-5" />
    </svg>
  );
}

function iconSpark() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6}>
      <path d="M12 3v4" />
      <path d="M12 17v4" />
      <path d="M5 8h4" />
      <path d="M15 16h4" />
      <path d="m7 17 10-10" />
    </svg>
  );
}

function iconRoute() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6}>
      <path d="M6 19H5a2 2 0 0 1-2-2v-2.5A2.5 2.5 0 0 1 5.5 12H8" />
      <path d="M16 12h2.5A2.5 2.5 0 0 1 21 14.5V17a2 2 0 0 1-2 2h-1" />
      <path d="M8 5h8" />
      <circle cx="6" cy="5" r="2" />
      <circle cx="18" cy="19" r="2" />
    </svg>
  );
}
